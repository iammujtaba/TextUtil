
from django.http import HttpResponse
from django.shortcuts import render
from string import punctuation
def index(request):
    return HttpResponse('''<h1>Below 5 Top Used WebSite Links are given</h1>
                        <a href="/home"> Click Here To Go For Text Analyzer Website </a>
                        <br>
                        <a href="https://www.google.co.in">Google India</a>
                        <br>
                        <a href="https://www.facebook.com"> Facebook</a>
                        <br>
                        <a href="https://www.amazon.in"> Amazon India </a>
                        <br>
                        <a href="https://www.playwithcplus.blogspot.in"> Play With C Plus Blog</a>''')

def home(request):
    return render(request,'home.html')

def analyze(request):
    txt=request.POST.get('text','default')
    removePunc=request.POST.get('removePunc','off')
    newLine=request.POST.get('newLine','off')
    removeSpaces=request.POST.get('removeSpaces','off')
    capitalize=request.POST.get('capitalize','off')
    countChar=request.POST.get('countChar','off')
   # print(txt)
#    print(newLine)
    
    if(removePunc=='on' and len(txt)!=0):
        s=""
        for i in txt:
            x=ord(i)
           # if(x>=65 and x<=90 or (x>=97 and x<=122) or i==" "):
            if(i not in punctuation):
                s+=i
        params={'getService':'Punctuations Remover','result':s,'original':txt}
    elif(newLine=='on' and len(txt)!=0):
        s="".join(txt.split("\n"))
        #s=""
 #       for i in txt:
 #           if(i=="\n"):
 #              # print("FOUND")
 #               continue
 #            else:
 #               s+=i
        #print(s,txt)
        params={'getService':'New Line Remover','result':s,'original':txt}
    elif(removeSpaces=='on' and len(txt)!=0):
        s=""
        for i in range(len(txt)-1):
            if(not(txt[i]==' ' and txt[i+1]==' ')):
                s+=txt[i]
                
        params={'getService':'Extra Space Remover','result':s,'original':txt}
    elif(capitalize=='on' and len(txt)!=0):
        s=txt.title()
        params={'getService':'Capitalize First Letter','result':s,'original':txt}
    elif(countChar=='on' and len(txt)!=0):
        ln=len(txt)
        params={'getService':'Length Of Text','result':ln,'original':txt}
    else:
        return HttpResponse("404 ERROR PAGE NOT FOUND")
    return render(request,'analyze.html',params)



#def about(request):
#    return HttpResponse('''<h1>This Is About Page</h1>
#                            <a href="removepunc">Go Back</a>''')
#def removepunc(request):
#    txt=request.GET.get('text','default')
#    if(len(txt)==0):
#        print("TextArea is Empty")
#    else:
#        print(txt)
#    return HttpResponse("Remove Punctuation Page")
#def newLine(request):
#    return HttpResponse("Remove NewLine from String")
#def  capital(request):
#    return HttpResponse("Capitalize the First Character")
#def count(request):
#    return HttpResponse("Count Character in String")    
#def spaceremove(request):
#    return HttpResponse("Remove Space from Words")   
